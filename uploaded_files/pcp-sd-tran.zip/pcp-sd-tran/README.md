# pcp-sd-tran

This capability enables Joule to interact with the Sales Order AI API and performs below functions

- Shows general information of sales order
- Shows general information about billing document
- Shows issues related to sales order
- Updates sales order on fileds like requested quantity, item description etc.
- creates a sales document based on the input like sales document type code or description of sales document type along with reference document number .

## Sample Prompts

### Show general information of sales order

- Summarize sales order 9952
- Show document flow associated with sales order 9952

### Show general information about billing document

- Show general information for 90097198 billing document
- Show document flow for 90097198 billing document

### Show issues related to sales order

- Show issues of the sales order 584858
- Explain the incomplete data in sales order 20007261

### Update sales order on fileds like requested quantity, item description etc.

- Change the requested quantity to 5 for item 10 for sales order 20002146
- Set the item description to value “Edward003” for item 10 in sales order 20002146

### Create sales order with reference:

- Create sales order of type OR with reference document number 20000115
- Create sales order of type 'Std. Order' with reference document number 20000115

### Create credit memo request with reference:

- Create credit memo of type CR with reference document 30000089
- Create credit memo of type 'Credit Memo Req. Val' with reference document number 30000089

### Create debit memo request with reference:

- Create debit memo of type DR with reference document 30000089
- Create debit memo of type 'Debit Memo Req. SB' with reference document number 30000089

### Create customer return request with reference:

- Create customer return of type RE2 with reference document 30000089
- Create customer return of type 'Lean return' with reference document number 30000089
