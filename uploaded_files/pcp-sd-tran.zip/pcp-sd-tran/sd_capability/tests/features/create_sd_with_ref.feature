@smokeTest
Feature: Create sales document i.e, Sales order, Credit memo request, Debit memo request, Customer returns

  Background: Initial state
    Given I log in
    And I start a new conversation

  Scenario: Details about the process flow for sales order creation
    When I say "Create sales order of type OR with reference document number 20007271"
    Then response has 2 messages
    And first message has type text
    And first message content contains "Here are the details for creation of Sales Order based on your inputs"

  Scenario: Details about the process flow for sales order creation
    When I say "Create credit memo request of type CR with reference document 90011291"
    Then response has 2 messages
    And first message has type text
    And first message content contains "Here are the details for creation of Credit Memo Req. based on your inputs"

  Scenario: Details about the process flow for sales order creation
    When I say "Create debit memo request of type DR with reference document 90011291"
    Then response has 2 messages
    And first message has type text
    And first message content contains "Here are the details for creation of Debit Memo Req. based on your inputs"

  Scenario: Details about the process flow for sales order creation
    When I say "Create customer return order of type RE2 with reference document 90011291"
    Then response has 2 messages
    And first message has type text
    And first message content contains "Here are the details for creation of Customer Return based on your inputs"

