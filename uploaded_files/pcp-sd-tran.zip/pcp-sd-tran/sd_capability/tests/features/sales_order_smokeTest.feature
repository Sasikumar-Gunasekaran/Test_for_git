@smokeTest

Feature: Display short summary about sales order

    Background: Initial state
        Given I log in
        And I start a new conversation

    Scenario: Display short summary about sales order
        When I say "Summarize sales order"
        Then response has 1 messages