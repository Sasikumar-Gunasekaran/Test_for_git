@devTest
Feature: General information for billing document

    Background: Initial state
        Given I log in
        And I start a new conversation

    Scenario: Fetch general information about billing document
        When I say "Show general information for 90097198 billing document"
        Then response has 1 messages
        And response relates to "general information for billing document 90097198"