@devTest

Feature: Display short summary about sales order

    Background: Initial state
        Given I log in
        And I start a new conversation

    Scenario: Display short summary about sales order
        When I say "Summarize sales order 9952"
        Then response has 1 messages
        And response relates to "summary of sales order 9952"