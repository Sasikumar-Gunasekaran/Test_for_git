@smokeTest

Feature: Display short summary about sales order

    Background: Initial state
        Given I log in
        And I start a new conversation

    Scenario: Fetch general information about billing document
        When I say "Show general information of billing document"
        Then response has 1 messages