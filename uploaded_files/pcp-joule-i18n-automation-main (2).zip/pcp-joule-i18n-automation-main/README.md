# pcp-joule-i18n-automation
automation for i18n enablement

Automated Python Script for i18n Implementation

This Python script streamlines the internationalization (i18n) process by automatically identifying static text and replacing it with the appropriate i18n syntax. This enhances efficiency and reduces manual effort for enabling i18n across various capabilities.

**Background**

1.	Objective: The script identifies all static text or strings found under `title`, `description`, `subtitle`, `label`, and `content`. 
2.	Script Type Detection: It analyzes the code to determine whether the scripting type is Handlebars or SpEL.
3.	Properties File Generation: It generates two properties files: messages.properties and messages_en.properties, using a predefined prefix ( ) in the generated   properties files.
4.	Variable Type Inclusion: Variable types are added to the properties file (e.g., XTIT for titles, XBUT for buttons). This is specifically applied when buttons are detected in a YAML file.
5.	i18n String Creation: The script generates i18n strings in YAML files, using the appropriate scripting type (Handlebars or SpEL) based on the code structure.
6.	Edge Case Handling: For scenarios involving multiple variables alongside static text, the script constructs i18n strings. These cases are documented as edge cases in the i18n handbook.
7.	Schema Version Update: The schema version is automatically updated to 3.7.0 in both capabilities and other relevant configuration files.
8.	Change Logging: The script logs all modifications, including changes to properties files and the specific YAML files affected, providing a clear before-and-after comparison in 'log.txt' file. 


**How to run the script**

1. Setup: Place the script in any desired folder.

2. Execution: Run the script using the following command format:
    ```
    python i18n_automated_script.py "C:\Users\work\pcp-gl-items-tran-main"
    ```

3. Outcome: After execution, the script implements the necessary changes in the corresponding folders and generates logs detailing all modifications.


**Manual Intervention for Edge Cases**
In certain scenarios, manual adjustments to the code may be required to handle edge cases. Below are some common situations and their solutions:

1.	**Joule Compile Errors**
    If joule compile generates errors, manual debugging may be necessary. A typical issue involves incorrect i18n syntax. In such cases, ensure that
	the appropriate scripting type is used—SpEL rather than Handlebars.
	For example:
	a. If joule compile flags unused keys, search for these keys in the codebase.
	b. If the scripting type is incorrectly set, switch to SpEL where required and manually correct the relevant lines of code.

    Examples:

![alt text](image.png)
![alt text](image-1.png)

2.	**Nested if-else Statements**
	The script handles basic i18n changes for if-else statements, such as:
	```
	{{#if api_error}} 
	  {{api_error}} 
	{{else}} 
	  Please try again 
	{{/if}} 
	```
	However, for complex cases involving nested if statements, like:
	```
	{{#if EAMProcessSubPhaseCodeDesc}}
	  {{EAMProcessSubPhaseCodeDesc}}
	{{else}}
	  {{#if IsFinallyConfirmed}}Confirmed{{/if}}
	{{/if}}
	```
	The script may fail to generate the correct i18n syntax. You will need to manually correct such cases.

3. **Unprocessed Elements: eachJoin, effect when, lookup, and add index**

    The script currently does not handle elements such as eachJoin, effect when, lookup, or add index. Below are some examples:

    - Effect When & EachJoin:
    ```
    {{notificationText}}\n > {{effect}}{{when}}
    {{#eachJoin issueData}}\n
    {{add @index 1}}) **Damage**: {{MaintNotifDamageCodeName}}
    ```
    - Add Index:
    ```
    {{add @index 1}}. {{OperationDescription}} ({{MaintenanceOrder}}/{{MaintenanceOrderOperation}})

    ```
    - Lookup:
    ```
    {lookup (lookup ../this this.[1])}
    ```
    - Ternary Operator:
    ```
    <? orderData.IsFinallyConfirmed ? 'Job is already confirmed' : 'Job is not assigned to you. You are not allowed to confirm the job' ?>
    ```
    For these cases, manual updates to the syntax are required.

4. **Single-Line Text Handling**
    Currently, the script processes only single-line text following keys such as subtitle, title, content, and description. Multi-line content, like the example below, is not supported:

    ```
    content: >-
    <? orderData.OperationPersonRespName != '' ? 'Job has been assigned to ' : '' ?><? orderData.OperationPersonRespName ?>
    <? orderData.OperationPersonRespName != '' ? '. Assignment of job will be changed to' : 'Job will be assigned to' ?>
    <? $transient.user.first_name ?> <? $transient.user.last_name ?>. Respond with 'yes' to confirm.
    ```

**Final Steps**
After completing all automated and manual changes:
    Review All Modifications: Carefully check (eyeball) every change to ensure accuracy.
    Deploy and Validate: Deploy the application using joule to confirm that everything functions as expected.