import os
import re
import sys
import logging
from collections import defaultdict
import json

# Check if the correct number of arguments is provided
if len(sys.argv) != 2:
    logging.info("Usage: python script.py <path_to_directory>")
    sys.exit(1)

# Get the directory path from the command-line argument
root_folder = sys.argv[1]

if not os.path.exists(root_folder):
    logging.error(f"Root folder '{root_folder}' does not exist. Please check the path.")
    sys.exit(1)

try:
    log_file_path = os.path.join(root_folder, "log.txt")
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(log_file_path),
            logging.StreamHandler(sys.stdout)
        ]
    )
except Exception as e:
    print(f"Failed to configure logging: {e}")
    sys.exit(1)

try:
    # Change the current working directory
    os.chdir(root_folder)
    logging.info(f"Changed working directory to: {os.getcwd()}")
except FileNotFoundError:
    logging.info(f"Error: The directory '{root_folder}' does not exist.")
    sys.exit(1)
except PermissionError:
    logging.error(f"Error: Permission denied to change to '{root_folder}'.")
    sys.exit(1)
except Exception as e:
    logging.error(f"An error occurred: {e}")
    sys.exit(1)

# Define regex patterns for keys to replace, matching full word with quotes
keys_to_replace = ["title", "description", "subtitle", "label", "content"]
pattern1 = {key: re.compile(rf'(?P<quotes>[\"\']?)\b(?P<key>{key})\b(?P=quotes):\s*\"(?P<value>.*?)\"') for key in
            keys_to_replace}

# Define regex patterns for conversation starters
conversation_key=["title","trigger_utterance"]
conversation_pattern = {key: re.compile(rf"(?P<quotes>[\"']?)\b(?P<key>{key})\b(?P=quotes):\s*(?P<value>[\"']?.*?[\"']?)(?=\n)") for key in conversation_key}

# Mapping of keys to their prefixes
prefix_mapping = {
    "description": "#XMSG",
    "subtitle": "#XMSG",
    "label": "#XMSG",
    "content": "#YINS"
}

value_to_variable = {}  # Store mapped values and their variable names
sanitized_name_count = {}  # Maintain counts to handle duplicate sanitized names
unique_values = {}  # Track unique values and their corresponding variable names

def sanitize_variable_name(value):
    """Sanitize and shorten variable names."""
    sanitized_name = re.sub(r"[^A-Z0-9_]", "", value.upper())[:10]
    if sanitized_name in sanitized_name_count:
        sanitized_name_count[sanitized_name] += 1
        sanitized_name = f"{sanitized_name}_{sanitized_name_count[sanitized_name]}"
    else:
        sanitized_name_count[sanitized_name] = 0
        logging.debug(f"Sanitized variable name: {sanitized_name}")
    return sanitized_name

def extract_placeholders_and_static(value):
    """Extract placeholders and static parts from the given value, supporting handlebars and PHP-style patterns."""
    # Define patterns for handlebars and PHP-style placeholders
    handlebars_pattern = re.compile(r'\{\{\s*(formatDate[^{}]+|[\w.]+)\s*\}\}')
    php_style_pattern = re.compile(r'<\?\s*(formatDate[^<>]+|[\w().]+)\s*\?>')  # Extended to include parentheses and dots

    placeholders = []  # To store extracted placeholders
    static_part = value

    # Replace handlebars placeholders
    def replace_handlebars(match):
        """Replace handlebars placeholders with {} and extract them."""
        content = match.group(1)
        if content.startswith("formatDate"):
            content = f"({content})"  # Wrap formatDate in parentheses
        placeholders.append(content)  # Append placeholder to list
        return "{}"  # Replace in static part

    # Replace PHP-style placeholders
    def replace_php(match):
        """Replace PHP-style placeholders with {} and extract them."""
        content = match.group(1)
        if content.startswith("formatDate"):
            content = f"({content})"  # Wrap formatDate in parentheses
        placeholders.append(content)  # Append placeholder to list
        return "{}"  # Replace in static part

    # Process handlebars placeholders
    static_part = handlebars_pattern.sub(replace_handlebars, static_part)

    # Process PHP-style placeholders
    static_part = php_style_pattern.sub(replace_php, static_part)

    # Handle case for placeholders in single quotes '{}'
    static_part = re.sub(r"'{}'", r"''{}''", static_part)

    # Handle case for placeholders in double quotes
    static_part = re.sub(r'"{}"', r'""{}""', static_part)
    
    return placeholders, static_part


def load_existing_properties(file_path):
    """Load properties from a file into a dictionary."""
    properties = {}
    if os.path.exists(file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if '=' in line and not line.startswith('#'):
                    variable_name, value = line.split('=', 1)
                    properties[variable_name.strip()] = value.strip()
    return properties

def update_properties(i18n_folder, key, value, title_prefix):
    """Update properties files if necessary."""

    placeholders, static_part = extract_placeholders_and_static(value)

    # Check if the value has already been processed
    if value in unique_values:
        existing_variable_name = unique_values[value]
        logging.info(f"Value '{value}' already processed. Using variable: {existing_variable_name}")
        return existing_variable_name, placeholders  # Return existing variable name and empty placeholders

    # Add to unique values
    files = [
        os.path.join(i18n_folder, "messages.properties")
    ]

    numbered_static_part = static_part.format(*[f"{{{i}}}" for i in range(len(placeholders))])

    sanitized_value_name = sanitize_variable_name(numbered_static_part).strip()

    # Create a new variable name if it doesn't exist
    variable_name = unique_values.get(value) or sanitized_value_name
    unique_values[value] = variable_name

    prefix = title_prefix if key == "title" else prefix_mapping.get(key, "#XMSG")
    placeholder_mapping = ', '.join(f"{{{i}}} is {placeholder}" for i, placeholder in enumerate(placeholders))

    for file_path in files:
        existing_properties = load_existing_properties(file_path)

        # Determine prefix based on the file name
        # prefix_val = 'en_' if 'messages_en.properties' in file_path else 'defa_'
        # prefixed_static_part = f"{prefix_val}{numbered_static_part}"
        prefixed_static_part=f"{numbered_static_part}"

        if variable_name not in existing_properties:  # Check if entry already exists
            with open(file_path, "a", encoding="utf-8") as f:
                if placeholder_mapping:
                    f.write(f"{prefix} , {placeholder_mapping}\n{variable_name}={prefixed_static_part}\n\n")
                else:
                    f.write(f"{prefix}\n{variable_name}={prefixed_static_part}\n\n")
                logging.info(f"Updated file: {file_path}\nAdded entry: {variable_name}={prefixed_static_part}\n")
        else:
            logging.info(f"Entry already exists in {file_path}: {variable_name}={prefixed_static_part}")
    return variable_name, placeholders

def should_use_handlebars(section_content, key_name): 
    # Check if 'scripting_type: handlebars' exists in the section content i
    if "scripting_type: handlebars" in section_content:  
        # Find the index of the key in the section content 
        key_index = section_content.find(key_name)  
        
        # Extract the text up to the key index t
        text_before_key = section_content[:key_index]  
        
        # Split the text into lines and get the last 3 lines 
        last_three_lines = [line.strip() for line in text_before_key.splitlines()][-3:]
        
        # Join these lines back into a string for pattern matching 
        last_three_lines_text = ''.join(last_three_lines)  
        
        # Check if 'message: type: text' appears in these lines 
        if "message:type: text" in last_three_lines_text: 
            return False  
        return True 
    return False


def generate_i18n_string(i18n_folder, key, match, use_handlebars, title_prefix):
    """Generate the i18n string for a matched value."""
    try:
        key_name = match.group("key")
        quotes = match.group("quotes")
        value = match.group("value").strip()

        # If value is empty, return as-is
        if not value:
            return f'{quotes}{key_name}{quotes}: "{value}"'

        # Regex to check if the value contains only variables (even if concatenated)

        only_variables_pattern = re.compile(r"^((\<\?\s*[\w\.\-\s]+\s*\?\>|\{\{\s*[\w\.\-\s]+\s*\}\})\W*)+$")

        #Check if the value contains only variables (including concatenated ones)
        if only_variables_pattern.match(value):
            # Skip processing and return the value as is if only variables are found
            return f'{quotes}{key_name}{quotes}: "{value}"'  # Keep the value unchanged

        # # Skip processing for edge cases
        
        if (
            "{{effect}}" in value 
            or "{{#eq" in value 
            or ('?' in value and ':' in value) 
            or "add @index" in value
            or "lookup" in value
        ):
            return f'{quotes}{key_name}{quotes}: "{value}"'
        
        if "{{#if" in value:

            # Check if the {{#if}} condition contains `lookup` or `{{effect}}`
            if_contains_condition = re.search(r"\{\{#if\s.*?(lookup|{{effect}}).*?\}\}", value)
            if if_contains_condition:
                return f'{quotes}{key_name}{quotes}: "{value}"'  # Skip processing

            # Process the if-else structure
            parts = process_if_else(value)
            if_part = parts['if']
            before_else = parts['before else']
            else_part = parts['else']
            after_else = parts['after else']
            end_if = parts['end if']

            # Check if `before_else` has only variables
            if only_variables_pattern.match(before_else.strip()):
                i18n_part1 = before_else.strip()  # Keep as-is
            else:
                # Process the parts before `else`
                part1_variable_name, part1_placeholders = update_properties(i18n_folder, key, before_else, title_prefix)

                part1_placeholders_str = ' '.join(part1_placeholders) if use_handlebars else ', '.join(part1_placeholders)
                i18n_part1 = f"{{i18n '{part1_variable_name}' {part1_placeholders_str}}}" if part1_placeholders_str else f"{{i18n '{part1_variable_name}'}}"

            # Check if `after_else` has only variables
            if after_else and only_variables_pattern.match(after_else.strip()):
                i18n_part2 = after_else.strip()  # Keep as-is
            else:
                # Process the parts after `else`
                part2_variable_name, part2_placeholders = update_properties(i18n_folder, key, after_else, title_prefix) if after_else else ("", [])

                part2_placeholders_str = ' '.join(part2_placeholders) if use_handlebars else ', '.join(part2_placeholders)
                i18n_part2 = f"{{i18n '{part2_variable_name}' {part2_placeholders_str}}}" if part2_placeholders_str else f"{{i18n '{part2_variable_name}'}}"

            # Return the formatted string
            return (
                f'{quotes}{key_name}{quotes}: "{if_part} {i18n_part1} '
                f'{else_part} {i18n_part2} {end_if}"'
            )

        else:
            # Process variable_name and placeholders
            variable_name, placeholders = update_properties(i18n_folder, key, value, title_prefix)

            # Prepare quoted key name
            quoted_key_name = f'{quotes}{key_name}{quotes}'

            if use_handlebars:
                # Handle Handlebars-specific processing
                placeholders_str = ' '.join(placeholders)
                if placeholders_str:
                    return f'{quoted_key_name}: "{{{{i18n \'{variable_name}\' {placeholders_str}}}}}"'
                else:
                    return f'{quoted_key_name}: "{{{{i18n \'{variable_name}\'}}}}"'
            else:
                # Handle default processing
                placeholders_str = ', '.join(placeholders)
                if placeholders_str:
                    return f'{quoted_key_name}: "<? new i18n(\'{variable_name}\', {placeholders_str}) ?>"'
                else:
                    return f'{quoted_key_name}: "<? new i18n(\'{variable_name}\') ?>"'

    except Exception as e:
        logging.info(f"Error processing key '{key}': {e}")
        return f'{quotes}{key_name}{quotes}: "{value}"'


def update_schema_version(content):
    """Update the schema_version to 3.9.0 in the given content."""
    return re.sub(r'schema_version:\s*\d+\.\d+\.\d+', 'schema_version: 3.9.0', content)


def get_changes(original_lines, updated_lines):
    """Identify changes between original and updated content."""
    changes = []
    max_length = max(len(original_lines), len(updated_lines))

    for i in range(max_length):
        original_line = original_lines[i] if i < len(original_lines) else ''
        updated_line = updated_lines[i] if i < len(updated_lines) else ''
        
        if original_line != updated_line:
            changes.append((original_line.strip(), updated_line.strip()))
    return changes

# function to add double quotes
def process_quotes_combined(match):
    key_part = match.group(1)  # The "key: " part
    value_part = match.group(2).strip()  # The text part after the key

    # Check if the value part starts with any word followed by a colon
    if re.match(r"^\s*\w+:\s*", value_part):  # Matches "word:"
        return match.group(0)  # Skip processing and return the original match

    # Remove any existing quotes (single or double) from the value part

    if value_part.startswith(("'", '"')):
        value_part = value_part[1:]
    
    if value_part.endswith(("'", '"')): 
        value_part = value_part[:-1] # remove last quote

    # Add double quotes around the value
    value_part = f'"{value_part}"'

    return f"{key_part}{value_part}"

# function to replace ' with '' for messages properties file
def replace_single_quotes(match):
    key_part=match.group(1)
    value_part=match.group(2).strip()

    def replace_apostrophe(match): 
        # Replace each ' in the matched substring with '' 
        return match.group(0).replace("'", "''")

    #replace single quotes to ''' 
    word_apostrophe_pattern =r"\b\w+'[\w]+\b"
    # Only replace single quotes if they are part of a word or possessive form 
    if not 'i18n' in value_part: 
        value_part = re.sub(word_apostrophe_pattern, replace_apostrophe, value_part)
    return f"{key_part}{value_part}"

# function for folded block
def remove_folded_indicator(section_content, key):
    # Regex pattern to match the key followed by `>` or `>-` and optional spaces
    pattern = rf"({key}:\s*)>-?\s*"
    
    # Replace the folded indicator (`>` or `>-`) with nothing
    section_content = re.sub(pattern, r"\1", section_content)
    return section_content

def process_if_else(value_part):
    # Define regex patterns
    if_pattern = r"{{#if\s+([^\}]+)}}"
    else_pattern = r"{{else}}"
    end_if_pattern = r"{{/if}}"

    # Initialize parts dictionary
    parts = {
        "if": None,
        "before else": None,
        "else": None,
        "after else": None,
        "end if": None
    }

    # Extract "if" part
    if_match = re.search(if_pattern, value_part)
    if if_match:
        parts["if"] = if_match.group(0)
        remaining_template = value_part[if_match.end():]

        # Look for "end if" tag in the remaining template
        end_if_match = re.search(end_if_pattern, remaining_template)
        if end_if_match:
            # Extract everything before "end if"
            before_end_if = remaining_template[:end_if_match.start()].strip()

            # Check if there's an "else" tag
            else_match = re.search(else_pattern, before_end_if)
            if else_match:
                parts["before else"] = before_end_if[:else_match.start()].strip()
                parts["else"] = else_match.group(0)
                parts["after else"] = before_end_if[else_match.end():].strip() or "(All)"
            else:
                parts["before else"] = before_end_if

            # Assign "end if" part
            parts["end if"] = end_if_match.group(0)

    return parts

def update_properties_cs(i18n_folder, value):
    """Update properties files if necessary."""

    static_part=value
    placeholders=[]
    print(static_part)

    # Check if the value has already been processed
    if value in unique_values:
        existing_variable_name = unique_values[value]
        logging.info(f"Value '{value}' already processed. Using variable: {existing_variable_name}")
        return existing_variable_name, placeholders  # Return existing variable name and empty placeholders

    # Add to unique values
    files = [
        os.path.join(i18n_folder, "messages.properties")
    ]

    numbered_static_part = static_part.format(*[f"{{{i}}}" for i in range(len(placeholders))])

    sanitized_value_name = sanitize_variable_name(numbered_static_part).strip()

    # Create a new variable name if it doesn't exist
    variable_name = unique_values.get(value) or sanitized_value_name
    unique_values[value] = variable_name

    placeholder_mapping = ', '.join(f"{{{i}}} is {placeholder}" for i, placeholder in enumerate(placeholders))

    for file_path in files:
        existing_properties = load_existing_properties(file_path)

        prefixed_static_part=f"{numbered_static_part}"

        if variable_name not in existing_properties:  # Check if entry already exists
            with open(file_path, "a", encoding="utf-8") as f:
                if placeholder_mapping:
                    f.write(f"{placeholder_mapping}\n{variable_name}={prefixed_static_part}\n\n")
                else:
                    f.write(f"{variable_name}={prefixed_static_part}\n\n")
                logging.info(f"Updated file: {file_path}\nAdded entry: {variable_name}={prefixed_static_part}\n")
        else:
            logging.info(f"Entry already exists in {file_path}: {variable_name}={prefixed_static_part}")
    return variable_name, placeholders


def generate_i18n_for_conversation_starter(i18n_folder, key, match):
    """Generate the i18n string for a matched value."""
    try:
        key_name = match.group("key")
        quotes = match.group("quotes")
        value = match.group("value").strip()

        # Process variable_name and placeholders
        variable_name, placeholders = update_properties_cs(i18n_folder, value)

        # Prepare quoted key name
        quoted_key_name = f'{quotes}{key_name}{quotes}'

        # New logic for handling placeholders
        if not placeholders:  # If placeholders is empty
            return f'{quoted_key_name}: $i18n.{variable_name}'
        
    except Exception as e:
        logging.info(f"Error processing key '{key}': {e}")
        return f'{quotes}{key_name}{quotes}: "{value}"'

    

# Main processing loop
for root, dirs, files in os.walk(root_folder):
    for dir_name in dirs:
        if dir_name.endswith("capability"):
            capability_path = os.path.join(root, dir_name)
            i18n_folder = os.path.join(capability_path, "i18n")
            os.makedirs(i18n_folder, exist_ok=True)

            for filename in ["messages.properties"]:
                file_path = os.path.join(i18n_folder, filename)

                if not os.path.exists(file_path):
                    with open(file_path, "w", encoding="utf-8") as f:
                        f.write("")
                    logging.info(f"Created file: {file_path}")

    for file in files:
        if file.endswith(".yaml") or file.endswith(".yml"):
            file_path = os.path.join(root, file)
            with open(file_path, "r", encoding="utf-8") as f:
                logging.info("File being read : ",file_path)
                content = f.read()

            title_prefix = "#XBUT" if "buttons" in content else "#XTIT"
            original_lines = content.splitlines()
            new_content = update_schema_version(content)

            sections = re.split(r'(conversation_starter:|actions:)', new_content)
            processed_content = sections[0]  # Initialize processed_content with the first section

            # Check if 'conversation_starter:' exists
            if 'conversation_starter:' in sections:
                starter_index = sections.index('conversation_starter:')
                if starter_index + 1 < len(sections):  # Ensure there's content after 'conversation_starter:'
                    for i in range(starter_index, len(sections), 2):
                        conversational_starter_header = sections[i]
                        conversation_section_content = sections[i + 1]  # Content after header
                        
                        for cs_key, cs_pattern in conversation_pattern.items():
                            def substitute_if_no_i18n(match):
                                current_line = match.group(0)
                                if 'i18n' in current_line:
                                    return current_line
                                return generate_i18n_for_conversation_starter(
                                    i18n_folder,
                                    cs_key,
                                    match
                                )

                            # Update the conversation starter content
                            conversation_section_content = re.sub(cs_pattern, substitute_if_no_i18n, conversation_section_content)
                        
                    # Append the updated conversation starter content
                    processed_content += conversational_starter_header + conversation_section_content
            else:
                logging.info("'conversation_starter:' not found, skipping to 'actions:' block.")

            # Process 'actions:' block
            if 'actions:' in sections:
                actions_index = sections.index('actions:')
                if actions_index + 1 < len(sections):  # Ensure there's content after 'actions:'
                    for i in range(actions_index, len(sections), 2):
                        actions_header = sections[i]
                        actions_section_content = sections[i + 1]  # Content after header

                        for key, pattern in pattern1.items():
                            actions_section_content = remove_folded_indicator(actions_section_content, key)

                            pattern_double_nested = rf"(\b{re.escape(key)}\b:\s*)([^\n]*)"
                            actions_section_content = re.sub(pattern_double_nested, process_quotes_combined, actions_section_content)

                            pattern_single_quotes = rf"({key}:\s*)([^\n]+)"
                            actions_section_content = re.sub(pattern_single_quotes, replace_single_quotes, actions_section_content)

                            use_handlebars = should_use_handlebars(actions_section_content, key)

                            def substitute_if_no_i18n(match):
                                current_line = match.group(0)
                                if 'i18n' in current_line:
                                    return current_line
                                return generate_i18n_string(
                                    i18n_folder,
                                    key,
                                    match,
                                    use_handlebars,
                                    title_prefix
                                )

                        # Update the actions content
                            actions_section_content = re.sub(pattern, substitute_if_no_i18n, actions_section_content)

                    # Append the updated actions content
                        processed_content += actions_header + actions_section_content

            updated_lines = processed_content.splitlines()
            changes = get_changes(original_lines, updated_lines)

            if changes:
                logging.info(f"\nChanges for file: {file_path}")

                grouped_changes = defaultdict(list)
                for original, updated in changes:
                    grouped_changes[original].append(updated)

                for original, updated_list in grouped_changes.items():
                    logging.info(f" - Original: {original}")
                    for idx, updated in enumerate(updated_list, 1):
                        logging.info(f"  + Change {idx}: {updated}")

                for original, updated in changes:
                    logging.info(f"- Original: {original}")
                    logging.info(f"+ Updated: {updated}")

                with open(file_path, "w", encoding="utf-8") as f:
                    f.write(processed_content)
                logging.info(f"Updated file: {file_path}")
            
            if not changes:
                logging.info(f"No changes for file: {file_path}")

logging.info("Processing complete.")

def create_json_file(root_folder: str, file_name: str):
    """
    Creates a JSON file with the specified name and content in the given root folder.

    Parameters:
        root_folder (str): The path to the root folder where the file will be saved.
        file_name (str): The name of the JSON file to create.

    Returns:
        None
    """
    # Define the content for the JSON file
    data = {
        "collections": [
            {
                "collectionName": "Joule_Content",
                "folders": [
                    {
                        "startingFolderPath": "**/i18n/**",
                        "sourceFilters": ["*.properties"]
                    }
                ]
            }
        ],
        "defaultConfiguration": {
            "targetFolderPath": ".",
            "pseudoLocFolderPath": ".",
            "oneQFolderPath": ".",
            "targetFileNamingConvention": "[filename]_[langCode].[extension]"
        }
    }

    # Ensure the directory exists
    os.makedirs(root_folder, exist_ok=True)

    # Full path to the JSON file
    file_path = os.path.join(root_folder, file_name)

    # Write the JSON data to the file
    with open(file_path, "w") as file:
        json.dump(data, file, indent=2)

    logging.info(f"'{file_path}' has been created.")


# Call the function
create_json_file(root_folder, "translation_v2.json")